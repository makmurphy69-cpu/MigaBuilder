var SITE = {
  name:    "Test Garage",
  phone:   "+46 70 123 45 67",
  email:   "hi@example.com",
  colors: {
    primary: "#654321",  // buttons
    dark:    "#111111"
  }
};
(function () { var DEFAULT_NAME = "Old Name"; document.title = document.title.split(DEFAULT_NAME).join(SITE.name); })();
