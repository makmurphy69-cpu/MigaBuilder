Two tiny test sites for the Website Builder zip loader.
